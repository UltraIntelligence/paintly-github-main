import { AlertCircleIcon, BellIcon, ClockIcon } from "lucide-react"
import { Card, CardHeader, CardTitle } from "@/components/ui/card"

export function AlertsSection() {
  const alerts = [
    {
      icon: BellIcon,
      title: "New staff availability submitted",
      description: "Instructor Maria Garcia has submitted availability for June. Review and approve.",
      type: "warning",
    },
    {
      icon: AlertCircleIcon,
      title: "Scheduling Conflicts",
      description: "2 scheduling conflicts detected for next week. Review and resolve.",
      type: "error",
    },
    {
      icon: ClockIcon,
      title: "Pending Staff Availability",
      description: "3 instructors have not submitted their availability for next month.",
      type: "info",
    },
  ]

  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-card pb-3">
        <CardTitle className="text-lg font-medium">Notifications</CardTitle>
      </CardHeader>
      <div className="space-y-0 divide-y">
        {alerts.map((alert, index) => (
          <div key={index} className="p-4 flex items-start gap-3 hover:bg-accent/50 transition-colors">
            <div
              className={`rounded-full p-1.5 ${
                alert.type === "warning" ? "bg-amber-100" : alert.type === "error" ? "bg-red-100" : "bg-blue-100"
              }`}
            >
              <alert.icon
                className={`h-4 w-4 ${
                  alert.type === "warning"
                    ? "text-amber-600"
                    : alert.type === "error"
                      ? "text-red-600"
                      : "text-blue-600"
                }`}
              />
            </div>
            <div>
              <h4 className="text-sm font-medium text-card-foreground">{alert.title}</h4>
              <p className="text-sm text-muted-foreground">{alert.description}</p>
            </div>
          </div>
        ))}
      </div>
    </Card>
  )
}
