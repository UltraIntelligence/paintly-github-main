"use client"
import type { LucideIcon } from "lucide-react"

// This component is now empty as requested
export function NavDocuments({
  items,
}: {
  items: {
    name: string
    url: string
    icon: LucideIcon
  }[]
}) {
  // Return null instead of the Documents section
  return null
}
