export function InstructorStats() {
  // Return null to effectively remove this component from rendering
  return null
}
